<!-- Chart pemasukkan -->
<script type="text/javascript">
    var ctx = document.getElementById("myChart").getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["Gaji", "Usaha", "Bonus", "Bunga", "Hadiah", "Lain-lain"],
            datasets: [{
                label: 'Data Pemasukkan',
                data: [
                <?php 
                $gaji = mysqli_query($koneksi,"SELECT * FROM pemasukkan WHERE username = '$username' AND (sumber='Gaji' AND tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir')");
                echo mysqli_num_rows($gaji);
                ?>, 
                <?php 
                $usaha = mysqli_query($koneksi,"SELECT * FROM pemasukkan WHERE username = '$username' AND (sumber='Usaha' AND tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir')");
                echo mysqli_num_rows($usaha);
                ?>, 
                <?php 
                $bonus = mysqli_query($koneksi,"SELECT * FROM pemasukkan WHERE username = '$username' AND (sumber='Bonus' AND tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir')");
                echo mysqli_num_rows($bonus);
                ?>, 
                <?php 
                $bunga = mysqli_query($koneksi,"SELECT * FROM pemasukkan WHERE username = '$username' AND (sumber='Bunga' AND tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir')");
                echo mysqli_num_rows($bunga);
                ?>, 
                <?php 
                $hadiah = mysqli_query($koneksi,"SELECT * FROM pemasukkan WHERE username = '$username' AND (sumber='Hadiah' AND tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir')");
                echo mysqli_num_rows($hadiah);
                ?>,
                <?php 
                $lainnya = mysqli_query($koneksi,"SELECT * FROM pemasukkan WHERE username = '$username' AND (sumber='Lainnya' AND tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir')");
                echo mysqli_num_rows($lainnya);
                ?>
                ],
                backgroundColor: [
                'rgba(255, 99, 132)',
                'rgba(54, 162, 235)',
                'rgba(255, 206, 86)',
                'rgba(75, 192, 192)',
                'rgba(153, 102, 255)'
                ],
                borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        }
    });
</script>

<!-- Chart pemasukkan -->
<script type="text/javascript">
    var ctx = document.getElementById("myChart2").getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ["Gaji", "Usaha", "Bonus", "Bunga", "Hadiah", "Lain-lain"],
            datasets: [{
                label: 'Data Pemasukkan',
                data: [
                <?php 
                    $gaji = mysqli_query($koneksi,"SELECT * FROM pemasukkan WHERE username = '$username' AND sumber='Gaji' AND tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir'");
                    $gajiSum = mysqli_num_rows($gaji);
                    while ($dataGaji = mysqli_fetch_assoc($gaji)) {
                        $jumlahGaji[] = $dataGaji['jumlah'];
                        $jumlahConvertGaji = str_replace('.', '', $jumlahGaji);
                        $totalGaji = array_sum($jumlahConvertGaji); 
                    }

                    if ($gajiSum != null) {
                        echo $totalGaji;
                    } elseif ($gajiSum == null) {
                        echo 0;
                    }
                ?>, 

                <?php 
                    $usaha = mysqli_query($koneksi,"SELECT * FROM pemasukkan WHERE username = '$username' AND sumber='Usaha' AND tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir'");
                    $usahaSum = mysqli_num_rows($usaha);
                    while ($dataUsaha = mysqli_fetch_assoc($usaha)) {
                        $jumlahUsaha[] = $dataUsaha['jumlah'];
                        $jumlahConvertUsaha = str_replace('.', '', $jumlahUsaha);
                        $totalUsaha = array_sum($jumlahConvertUsaha);
                    }

                    if ($usahaSum != null) {
                        echo $totalUsaha;
                    } elseif ($usahaSum == null) {
                        echo 0;
                    }
                ?>, 

                <?php 
                    $bonus = mysqli_query($koneksi,"SELECT * FROM pemasukkan WHERE username = '$username' AND sumber='Bonus' AND tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir'");
                    $bonusSum = mysqli_num_rows($bonus);
                    while ($dataBonus = mysqli_fetch_assoc($bonus)) {
                        $jumlahBonus[] = $dataBonus['jumlah'];
                        $jumlahConvertBonus = str_replace('.', '', $jumlahBonus);
                        $totalBonus = array_sum($jumlahConvertBonus);
                    }

                    if ($bonusSum != null) {
                        echo $totalBonus;
                    } elseif ($bonusSum == null) {
                        echo 0;
                    }
                ?>, 

                <?php 
                    $bunga = mysqli_query($koneksi,"SELECT * FROM pemasukkan WHERE username = '$username' AND sumber='Bunga' AND tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir'");
                    $bungaSum = mysqli_num_rows($bunga);
                    while ($dataBunga = mysqli_fetch_assoc($bunga)) {
                        $jumlahBunga[] = $dataBunga['jumlah'];
                        $jumlahConvertBunga = str_replace('.', '', $jumlahBunga);
                        $totalBunga = array_sum($jumlahConvertBunga);
                    }

                    if ($bungaSum != null) {
                        echo $totalBunga;
                    } elseif ($bungaSum == null) {
                        echo 0;
                    }
                ?>, 

                <?php 
                    $hadiah = mysqli_query($koneksi,"SELECT * FROM pemasukkan WHERE username = '$username' AND sumber='Hadiah' AND tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir'");
                    $hadiahSum = mysqli_num_rows($hadiah);
                    while ($dataHadiah = mysqli_fetch_assoc($hadiah)) {
                        $jumlahHadiah[] = $dataHadiah['jumlah'];
                        $jumlahConvertHadiah = str_replace('.', '', $jumlahHadiah);
                        $totalHadiah = array_sum($jumlahConvertHadiah);
                    }
                    
                    if ($hadiahSum != null) {
                        echo $totalHadiah;
                    } elseif ($hadiahSum == null) {
                        echo 0;
                    }
                ?>,
                <?php 
                    $lainnya = mysqli_query($koneksi,"SELECT * FROM pemasukkan WHERE username = '$username' AND sumber='Lainnya' AND tanggal BETWEEN '$tanggalAwal' AND '$tanggalAkhir'");
                    $lainnyaSum = mysqli_num_rows($lainnya);
                    while ($dataLainnya = mysqli_fetch_assoc($lainnya)) {
                        $jumlahLainnya[] = $dataLainnya['jumlah'];
                        $jumlahConvertLainnya = str_replace('.', '', $jumlahLainnya);
                        $totalLainnya = array_sum($jumlahConvertLainnya);
                    }
                    
                    if ($lainnyaSum != null) {
                        echo $totalLainnya;
                    } elseif ($lainnyaSum == null) {
                        echo 0;
                    }
                ?>
                ],
                backgroundColor: [
                'rgba(255, 99, 132)',
                'rgba(54, 162, 235)',
                'rgba(255, 206, 86)',
                'rgba(75, 192, 192)',
                'rgba(153, 102, 255)'
                ],
                borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)'
                ],
                borderWidth: 1
            }]
        }
    });
</script>