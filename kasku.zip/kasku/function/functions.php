<?php
 
    $koneksi = mysqli_connect('localhost', 'root', '', 'hy025uji-ecash');

    if (mysqli_connect_error() == true) {
        die('<br><h3>Gagal terhubung ke database !</h3>');
        return false;
    } else {
        return true;
    }

    //hy033uji-kasku
    
    function query($query) {
        global $koneksi;
        $result = mysqli_query($koneksi, $query);
        $rows = [];
        while( $row = mysqli_fetch_assoc($result) ) {
            $rows[] = $row;
        }
        return $rows;
    }

    // tambah data Pemasukkan
    function tambahMasuk($dataMasuk) {
        global $koneksi;
        $tanggalMasuk = htmlspecialchars($dataMasuk["tanggal"]);
        $keteranganMasuk = htmlspecialchars($dataMasuk["keterangan"]);
        $sumber = htmlspecialchars($dataMasuk["sumber"]);
        $jumlah = htmlspecialchars($dataMasuk["jumlah"]);
        $username = $dataMasuk["username"];

        // query insert data
        $query = "INSERT INTO pemasukkan (id, tanggal, keterangan, sumber, jumlah, username) VALUES (NULL, '$tanggalMasuk', '$keteranganMasuk', '$sumber', '$jumlah', '$username')";
        mysqli_query($koneksi, $query);           
        
        return mysqli_affected_rows($koneksi);
    }

    // tambah data Pengeluaran
    function tambahKeluar($dataKeluar) {
        global $koneksi;
        $tanggalKeluar = htmlspecialchars($dataKeluar["tanggal"]);
        $keteranganKeluar = htmlspecialchars($dataKeluar["keterangan"]);
        $keperluan = htmlspecialchars($dataKeluar["keperluan"]);
        $jumlah = htmlspecialchars($dataKeluar["jumlah"]);
        $username = $dataKeluar["username"];

        // query insert data
        $query = "INSERT INTO pengeluaran (id, tanggal, keterangan, keperluan, jumlah, username) VALUES (NULL, '$tanggalKeluar', '$keteranganKeluar', '$keperluan', '$jumlah', '$username')";
        mysqli_query($koneksi, $query);           
        
        return mysqli_affected_rows($koneksi);
    }

    // tanggal indonesia
    function tgl_indo($tgl) {
        $tanggal = substr($tgl, 8, 2);
        $nama_bulan = array("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Ags", "Sep", "Okt", "Nov", "Des");
        $bulan = $nama_bulan[substr($tgl, 5, 2) - 1];
        $tahun = substr($tgl, 0, 4);

        return $tanggal.'-'.$bulan.'-'.$tahun;
    }
    
    // fungsi transfer
    function transfer($dataTransfer) {
        global $koneksi;
        $username = $dataTransfer['username'];
        $username2 = $dataTransfer['username2'];
        $tanggal = $dataTransfer['tanggal'];
        $saldoRekening = $dataTransfer['saldoRekening'];
        $jumlah = htmlspecialchars($dataTransfer['jumlah']);
        $jumlahConvert = str_replace('.', '', $jumlah);

        if ($jumlahConvert > $saldoRekening) {
            echo "
                <script>
                    alert('Maaf, saldo anda tidak cukup!');
                </script>
                ";
            return false;
        }
        // query insert data
        $query = "INSERT INTO rekening_masuk(jumlah, tanggal, username) VALUES('$jumlah', '$tanggal', '$username')";
        $query2 = "INSERT INTO rekening_keluar(jumlah, tanggal, username) VALUES('$jumlah', '$tanggal', '$username2')";
        mysqli_query($koneksi, $query);
        mysqli_query($koneksi, $query2);

        return mysqli_affected_rows($koneksi);
    }

    // fungsi generate no rek
    function acak($panjang)
    {
        $karakter = '1234567890';
        $string = '';
        for ($i = 0; $i < $panjang; $i++) {
            $pos = rand(0, strlen($karakter) - 1);
            $string .= $karakter{
            $pos};
        }
        return $string;
    }

    function register($dataRegister)
    {
        global $koneksi;

        $email = htmlspecialchars(stripcslashes($dataRegister['email-registrasi']));
        $username = htmlspecialchars(stripcslashes($dataRegister['username-registrasi']));
        $password = mysqli_real_escape_string($koneksi, htmlspecialchars($dataRegister['password-registrasi']));
        $passwordConfirm = mysqli_real_escape_string($koneksi, htmlspecialchars($dataRegister['password-confirm']));

        $cekUser = mysqli_query($koneksi, "SELECT email, username FROM users WHERE email = '$email' OR username = '$username'");

        // cek username dan email
        if (mysqli_num_rows($cekUser) > 0) {
            echo "
                <script>
                    swal('Maaf','Username / Email telah Terdaftar !','info');
                </script>
            ";
            return false;
        }

        // cek konfirmasi password
        if ($password != $passwordConfirm) {
            echo "
                <script>
                    swal('Maaf', 'Konfirmasi Password tidak sesuai !','info');
                </script>
            ";
            return false;
        }

        $password = password_hash($password, PASSWORD_DEFAULT);
        $no_rek = acak(12);
        $sukses = mysqli_query($koneksi, "INSERT INTO users (email, username, password, no_rek) VALUES ('$email', '$username', '$password', '$no_rek')");

        if ($sukses > 0) {
            echo "
        <script>
            swal('Berhasil','Akun anda berhasil didaftarkan !','success');
        </script>
        ";
        } else {
            echo "
                <script>
                swal('Maaf',Akun anda gagal didaftarkan !','warning');
                </script>
            ";
            return false;
        }

        return mysqli_affected_rows($koneksi);
    }

    function login($dataLogin)
    {
        global $koneksi;

        $email = $dataLogin['user-email'];
        $username = $dataLogin['user-email'];
        $password = $dataLogin['password-login'];

        $cekUser = mysqli_query($koneksi, "SELECT * FROM users WHERE email = '$email' OR username = '$username'");

        if (mysqli_num_rows($cekUser) === 1) {
            $hasil = mysqli_fetch_assoc($cekUser);

            if (password_verify($password, $hasil["password"])) {
                if ($hasil['status'] == 'aktif') {

                    if ($hasil['level'] == 'admin') {
                        $_SESSION['user'] = $hasil['username'];
                        $_SESSION['level'] = 'admin';
                        $_SESSION['login'] = true;
                        header('Location: administrator');
                    } elseif ($hasil['level'] == 'user') {
                        $_SESSION['user'] = $hasil['username'];
                        $_SESSION['level'] = 'user';
                        $_SESSION['login'] = true;
                        header('Location: dashboard');
                    }

                    if (isset($_POST['rememberme'])) {
                        setcookie('login', $hasil['username'], time() + 3600);
                        setcookie('level', $hasil['level'], time() + 3600);
                        setcookie('id', $hasil['id_user'], time() + 3600);
                        setcookie('key', hash('sha256', $hasil['username']), time() + 3600);
                    }
                } elseif ($hasil['status'] == 'tidak aktif') {
                    echo "
                        <script>
                            swal('Maaf','Akun Nonaktif. Silahkan hubungi Administrator !','info');
                        </script>
                    ";
                    return false;
                }
            } else {
                echo "
                    <script>
                    swal('Maaf','Username / Password salah !','warning');
                    </script>
                ";
                return false;
            }
        } else {
            echo "
                <script>
                    swal('Maaf','Username / Password salah !','warning');
                </script>
            ";
            return false;
        }

        return mysqli_affected_rows($koneksi);
    }